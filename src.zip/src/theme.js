import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    primary: { main: "#37474F" },  // Steel grey
    secondary: { main: "#FFD600" }, // Yellow
    background: { default: "#ECEFF1", paper: "#CFD8DC" },
  },
  typography: {
    fontFamily: "Roboto, sans-serif",
  },
});

export default theme;
