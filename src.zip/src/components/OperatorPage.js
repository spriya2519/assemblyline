import React, { useState } from "react";
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Paper,
  Snackbar,
  Alert,
  AppBar,
  Toolbar,
  IconButton,
  Grid,
  CardActionArea,
} from "@mui/material";

import LogoutIcon from "@mui/icons-material/Logout";
import { AssignmentTurnedIn, EditNote } from "@mui/icons-material";

const OperatorPage = ({ onLogout }) => {
  const [tasks, setTasks] = useState([
    { id: 1, name: "Inspect Material", status: "Pending" },
    { id: 2, name: "Assemble Parts", status: "Pending" },
    { id: 3, name: "Quality Check", status: "Completed" },
  ]);

  const [correction, setCorrection] = useState("");
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [selected, setSelected] = useState(null);

  const handleComplete = (id) => {
    const updated = tasks.map((task) =>
      task.id === id ? { ...task, status: "Completed" } : task
    );
    setTasks(updated);
    setOpenSnackbar(true);
  };

  const handleRequestCorrection = () => {
    if (!correction.trim()) return alert("Please enter your correction details");

    alert(`Correction Request Sent:\n${correction}`);
    setCorrection("");
  };

  return (
    <Box sx={{ minHeight: "100vh", bgcolor: "#F1F5F9" }}>
      {/* Top Bar */}
      <AppBar
        position="static"
        sx={{
          bgcolor: "#3949AB",
          boxShadow: 3,
        }}
      >
        <Toolbar>
          <Typography variant="h5" sx={{ flexGrow: 1, fontWeight: 600 }}>
            {selected ? selected : "Operator Dashboard"}
          </Typography>

          <IconButton color="inherit" onClick={onLogout}>
            <LogoutIcon sx={{ fontSize: 26 }} />
          </IconButton>
        </Toolbar>
      </AppBar>

      {/* ======= MENU CARDS ======= */}
      {!selected && (
        <Grid
          container
          spacing={4}
          sx={{
            p: 5,
            display: "flex",
            justifyContent: "center",
            animation: "fadeIn 0.4s ease",
            "@keyframes fadeIn": {
              from: { opacity: 0, transform: "translateY(10px)" },
              to: { opacity: 1, transform: "translateY(0)" },
            },
          }}
        >
          {/* Tasks Card */}
          <Grid item xs={12} sm={6} md={3}>
            <Card
              sx={{
                height: 200,
                borderRadius: 3,
                background: "#1E293B",
                color: "white",
                boxShadow: "0 6px 20px rgba(0,0,0,0.18)",
                transition: "0.35s ease",
                "&:hover": {
                  transform: "translateY(-10px)",
                  boxShadow: "0 12px 32px rgba(57, 73, 171, 0.4)",
                },
              }}
            >
              <CardActionArea
                sx={{ height: "100%" }}
                onClick={() => setSelected("My Tasks")}
              >
                <CardContent
                  sx={{
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <AssignmentTurnedIn sx={{ fontSize: 55, color: "white" }} />
                  <Typography variant="h6" sx={{ mt: 2, fontWeight: 600 }}>
                    My Tasks
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>

          {/* Corrections Card */}
          <Grid item xs={12} sm={6} md={3}>
            <Card
              sx={{
                height: 200,
                borderRadius: 3,
                background: "#1E293B",
                color: "white",
                boxShadow: "0 6px 20px rgba(0,0,0,0.18)",
                transition: "0.35s ease",
                "&:hover": {
                  transform: "translateY(-10px)",
                  boxShadow: "0 12px 32px rgba(57, 73, 171, 0.4)",
                },
              }}
            >
              <CardActionArea
                sx={{ height: "100%" }}
                onClick={() => setSelected("Corrections")}
              >
                <CardContent
                  sx={{
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <EditNote sx={{ fontSize: 55, color: "white" }} />
                  <Typography variant="h6" sx={{ mt: 2, fontWeight: 600 }}>
                    Corrections
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* ======= CONTENT AREA (Same style as AdminDashboard) ======= */}
      {selected && (
        <Box
          sx={{
            p: 4,
            animation: "zoom 0.4s ease",
            "@keyframes zoom": {
              from: { opacity: 0, transform: "scale(0.96)" },
              to: { opacity: 1, transform: "scale(1)" },
            },
          }}
        >
          <Card
            sx={{
              p: 3,
              borderRadius: 3,
              boxShadow: "0 6px 20px rgba(0,0,0,0.15)",
              background: "white",
            }}
          >
            <Typography
              variant="h4"
              sx={{ mb: 2, fontWeight: "700", color: "#3949AB" }}
            >
              {selected}
            </Typography>

            {/* Back Button */}
            <Typography
              sx={{
                mb: 3,
                cursor: "pointer",
                color: "#3949AB",
                fontSize: 18,
                fontWeight: 600,
                "&:hover": { textDecoration: "underline" },
              }}
              onClick={() => setSelected(null)}
            >
              ← Back to Menu
            </Typography>

            {/* ================= My Tasks ================= */}
            {selected === "My Tasks" && (
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Assigned Tasks
                </Typography>

                <Table component={Paper} sx={{ borderRadius: "10px" }}>
                  <TableHead>
                    <TableRow sx={{ backgroundColor: "#E0E0E0" }}>
                      <TableCell><b>Task Name</b></TableCell>
                      <TableCell><b>Status</b></TableCell>
                      <TableCell><b>Action</b></TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {tasks.map((task) => (
                      <TableRow key={task.id}>
                        <TableCell>{task.name}</TableCell>
                        <TableCell>{task.status}</TableCell>
                        <TableCell>
                          {task.status === "Pending" ? (
                            <Button
                              variant="contained"
                              color="success"
                              size="small"
                              sx={{ borderRadius: "8px" }}
                              onClick={() => handleComplete(task.id)}
                            >
                              Mark Complete
                            </Button>
                          ) : (
                            <Typography color="success.main">✔ Completed</Typography>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            )}

            {/* ================= Corrections ================= */}
            {selected === "Corrections" && (
              <CardContent sx={{ width: "70%" }}>
                <Typography variant="h6" gutterBottom>
                  Request for Process Correction
                </Typography>

                <TextField
                  label="Describe issue or correction required"
                  multiline
                  rows={4}
                  fullWidth
                  sx={{ mb: 2 }}
                  value={correction}
                  onChange={(e) => setCorrection(e.target.value)}
                />

                <Button
                  variant="contained"
                  color="warning"
                  sx={{ borderRadius: "10px" }}
                  onClick={handleRequestCorrection}
                >
                  Send Request
                </Button>
              </CardContent>
            )}
          </Card>
        </Box>
      )}

      {/* Snackbar */}
      <Snackbar
        open={openSnackbar}
        autoHideDuration={2000}
        onClose={() => setOpenSnackbar(false)}
      >
        <Alert onClose={() => setOpenSnackbar(false)} severity="success">
          Task marked as completed!
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default OperatorPage;
