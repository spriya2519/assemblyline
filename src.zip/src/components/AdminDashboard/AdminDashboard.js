import React, { useState } from "react";
import {
  Box,
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Grid,
  Card,
  CardActionArea,
  CardContent,
} from "@mui/material";

import LogoutIcon from "@mui/icons-material/Logout";
import { Dashboard, PlaylistAdd, Build, GroupAdd } from "@mui/icons-material";

import AddProject from "./AddProject";
import AddProcess from "./AddProcess";
import ManageUsers from "./ManageUsers";
import DashboardView from "./DashboardView";

// Menu Items - same industry color
const menuItems = [
  { text: "Dashboard", icon: <Dashboard sx={{ fontSize: 55, color: "white" }} />, component: <DashboardView /> },
  { text: "Add Project", icon: <PlaylistAdd sx={{ fontSize: 55, color: "white" }} />, component: <AddProject /> },
  { text: "Add Process", icon: <Build sx={{ fontSize: 55, color: "white" }} />, component: <AddProcess /> },
  { text: "Manage Users", icon: <GroupAdd sx={{ fontSize: 55, color: "white" }} />, component: <ManageUsers /> },
];

export default function AdminDashboard({ onLogout }) {
  const [selected, setSelected] = useState(null);

  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "#F1F5F9", // soft professional grey
      }}
    >
      {/* Top Bar */}
      <AppBar
        position="static"
        sx={{
          bgcolor: "#3949AB", // Indigo industry color
          boxShadow: 3,
        }}
      >
        <Toolbar>
          <Typography variant="h5" sx={{ flexGrow: 1, fontWeight: "600" }}>
            {selected ? selected.text : "Admin Panel"}
          </Typography>
          <IconButton color="inherit" onClick={onLogout}>
            <LogoutIcon sx={{ fontSize: 26 }} />
          </IconButton>
        </Toolbar>
      </AppBar>

      {/* Menu Grid – Professional Cards */}
      {!selected && (
        <Grid
          container
          spacing={4}
          sx={{
            p: 5,
            display: "flex",
            justifyContent: "center",
            animation: "fadeIn 0.4s ease",
            "@keyframes fadeIn": {
              from: { opacity: 0, transform: "translateY(10px)" },
              to: { opacity: 1, transform: "translateY(0)" },
            },
          }}
        >
          {menuItems.map((item) => (
            <Grid item xs={12} sm={6} md={3} key={item.text}>
              <Card
                sx={{
                  height: 200,
                  borderRadius: 3,
                  background: "#1E293B", // Slate grey—industry UI
                  color: "white",
                  boxShadow: "0 6px 20px rgba(0,0,0,0.18)",
                  transition: "0.35s ease",
                  "&:hover": {
                    transform: "translateY(-10px)",
                    boxShadow: "0 12px 32px rgba(57, 73, 171, 0.4)", // indigo glow
                  },
                }}
              >
                <CardActionArea sx={{ height: "100%" }} onClick={() => setSelected(item)}>
                  <CardContent
                    sx={{
                      height: "100%",
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    {item.icon}
                    <Typography variant="h6" sx={{ mt: 2, fontWeight: 600 }}>
                      {item.text}
                    </Typography>
                  </CardContent>
                </CardActionArea>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}

      {/* Selected Component Container */}
      {selected && (
        <Box
          sx={{
            p: 4,
            animation: "zoom 0.4s ease",
            "@keyframes zoom": {
              from: { opacity: 0, transform: "scale(0.96)" },
              to: { opacity: 1, transform: "scale(1)" },
            },
          }}
        >
          <Card
            sx={{
              p: 3,
              borderRadius: 3,
              boxShadow: "0 6px 20px rgba(0,0,0,0.15)",
              background: "white",
            }}
          >
            <Typography
              variant="h4"
              sx={{ mb: 2, fontWeight: "700", color: "#3949AB" }}
            >
              {selected.text}
            </Typography>

            {/* Back to menu */}
            <Typography
              sx={{
                mb: 3,
                cursor: "pointer",
                color: "#3949AB",
                fontSize: 18,
                fontWeight: 600,
                "&:hover": { textDecoration: "underline" },
              }}
              onClick={() => setSelected(null)}
            >
              ← Back to Menu
            </Typography>

            {selected.component}
          </Card>
        </Box>
      )}
    </Box>
  );
}
