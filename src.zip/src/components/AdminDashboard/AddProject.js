import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Grid,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TextField,
  Checkbox,
  Snackbar,
  Alert,
  Divider,
} from "@mui/material";

// ICONS
import UploadFileIcon from "@mui/icons-material/UploadFile";
import AddIcon from "@mui/icons-material/Add";
import DeleteIcon from "@mui/icons-material/Delete";
import ReplayIcon from "@mui/icons-material/Replay";
import ListAltIcon from "@mui/icons-material/ListAlt";
import FolderOffIcon from "@mui/icons-material/FolderOff";

import axios from "axios";

export default function AddProject() {
  const [tab, setTab] = useState("upload");

  const [previewRows, setPreviewRows] = useState([]);
  const [masterList, setMasterList] = useState([]);
  const [inactiveList, setInactiveList] = useState([]);
  const [columns, setColumns] = useState([]);
  const [serialColumn, setSerialColumn] = useState("");
  const [fileName, setFileName] = useState("");
  const [alert, setAlert] = useState({ open: false, msg: "", type: "error" });

  const [lastUpdated, setLastUpdated] = useState(null); // ← NEW

  // Fetch existing masterlist
  useEffect(() => {
    axios.get("http://localhost:5000/api/masterlist").then((res) => {
      if (res.data?.length > 0) {
        setMasterList(res.data);
      }
    });

    // Fetch last updated date if available
    axios.get("http://localhost:5000/api/masterlist/lastUpdated").then((res) => {
      if (res.data?.lastUpdated) setLastUpdated(res.data.lastUpdated);
    });

  }, []);

  // Excel upload handler
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (evt) => {
      const buffer = new Uint8Array(evt.target.result);
      const wb = XLSX.read(buffer, { type: "array" });
      const ws = wb.Sheets[wb.SheetNames[0]];
      let json = XLSX.utils.sheet_to_json(ws);

      if (json.length === 0) {
        showAlert("Excel file is empty!", "error");
        return;
      }

      const cols = Object.keys(json[0]);
      setColumns(cols);

      const serialCol = cols.find(
        (c) => c.toLowerCase().replace(/\s+/g, "") === "serialnumber"
      );
      setSerialColumn(serialCol);

      const rows = json.map((row, i) => ({
        id: Date.now() + "-" + i,
        ...row,
      }));

      setPreviewRows(rows);
      setTab("preview");
    };

    reader.readAsArrayBuffer(file);
  };

  const addRow = () => {
    const newRow = { id: Date.now() };
    columns.forEach((c) => (newRow[c] = ""));
    setPreviewRows((p) => [...p, newRow]);
  };

  const deleteRow = (id) => {
    setPreviewRows((p) => p.filter((row) => row.id !== id));
  };

  const updateCell = (id, key, value) => {
    setPreviewRows((p) =>
      p.map((row) => (row.id === id ? { ...row, [key]: value } : row))
    );
  };

  // SAVE TO MASTERLIST (STRICT NO-DUPLICATES)
  const saveToMaster = () => {
    let existingSerials = new Set(
      masterList.map((r) => (serialColumn ? String(r[serialColumn]).trim() : null))
    );

    let finalAdd = [];
    let dupCount = 0;

    previewRows.forEach((r) => {
      const serialValue = serialColumn ? String(r[serialColumn]).trim() : "";

      if (!serialValue || existingSerials.has(serialValue)) {
        dupCount++;
      } else {
        existingSerials.add(serialValue);
        finalAdd.push({ ...r, status: "Not Assigned" });
      }
    });

    if (dupCount > 0) {
      showAlert(`${dupCount} duplicate serial numbers skipped.`, "warning");
    }

    const final = [...masterList, ...finalAdd];
    setMasterList(final);

    // Save last updated date
    const now = new Date().toLocaleString();
    setLastUpdated(now);

    axios.post("http://localhost:5000/api/masterlist", {
      data: final,
      lastUpdated: now,
    });

    setTab("master");
  };

  const toggleAssign = (id) => {
    setMasterList((p) =>
      p.map((row) =>
        row.id === id
          ? { ...row, status: row.status === "Assigned" ? "Not Assigned" : "Assigned" }
          : row
      )
    );
  };

  const pushToInactive = () => {
    const selected = masterList.filter((r) => r.status === "Assigned");
    const moved = selected.map((r) => ({ ...r, status: "Incomplete" }));

    setInactiveList((p) => [...p, ...moved]);
    setMasterList((p) => p.filter((r) => r.status !== "Assigned"));

    setTab("inactive");
  };
  useEffect(()=>{
    if(inactiveList.length>0){
      inactiveList.setItem('inactiveList',JSON.stringify(inactiveList))
    }

  },[inactiveList])
  const reassign = (id) => {
    const row = inactiveList.find((r) => r.id === id);
    const updated = { ...row, status: "Not Assigned" };

    setMasterList((p) => [...p, updated]);
    setInactiveList((p) => p.filter((r) => r.id !== id));

    setTab("master");
  };

  const showAlert = (msg, type) => {
    setAlert({ open: true, msg, type });
  };

  const TabButton = ({ icon, label, value }) => (
    <Card
      sx={{
        p: 2,
        cursor: "pointer",
        borderRadius: 3,
        background:
          tab === value ? "linear-gradient(45deg, #42a5f5, #478ed1)" : "#ffffff",
        color: tab === value ? "white" : "black",
        boxShadow: 3,
        "&:hover": { boxShadow: 6 },
      }}
      onClick={() => setTab(value)}
    >
      <CardContent sx={{ textAlign: "center" }}>
        {icon}
        <Typography sx={{ mt: 1 }}>
          <b>{label}</b>
        </Typography>
      </CardContent>
    </Card>
  );

  return (
    <Box p={3}>

      {/* TOP NAVIGATION */}
      <Grid container spacing={2}>
        <Grid item xs={4}>
          <TabButton value="upload" label="Upload Excel" icon={<UploadFileIcon fontSize="large" />} />
        </Grid>
        <Grid item xs={4}>
          <TabButton value="master" label="Master List" icon={<ListAltIcon fontSize="large" />} />
        </Grid>
        <Grid item xs={4}>
          <TabButton value="inactive" label="Inactive" icon={<FolderOffIcon fontSize="large" />} />
        </Grid>
      </Grid>

      {/* UPLOAD */}
      {tab === "upload" && (
        <Card sx={{ mt: 3, p: 3, borderRadius: 3, boxShadow: 4 }}>
          <Typography variant="h6" sx={{ mb: 1, color: "#1976d2" }}>
            Upload Excel File
          </Typography>
          <Divider sx={{ mb: 2 }} />

          <Typography variant="body2" sx={{ mb: 2 }}>
            {fileName || "No file selected"}
          </Typography>

          <Button variant="contained" component="label" startIcon={<UploadFileIcon />} sx={{ borderRadius: 2 }}>
            Browse File
            <input type="file" hidden onChange={handleFileUpload} />
          </Button>
        </Card>
      )}

      {/* PREVIEW */}
      {tab === "preview" && (
        <Card sx={{ mt: 3, p: 3, borderRadius: 3, boxShadow: 4 }}>
          <Typography variant="h6" sx={{ mb: 1, color: "#8e24aa" }}>
            Preview & Edit Data
          </Typography>
          <Divider sx={{ mb: 2 }} />

          <Button
            startIcon={<AddIcon />}
            variant="contained"
            sx={{
              mb: 2,
              background: "#8e24aa",
              "&:hover": { background: "#6a1b9a" },
            }}
            onClick={addRow}
          >
            Add Row
          </Button>

          <Table>
            <TableHead sx={{ background: "#f3e5f5" }}>
              <TableRow>
                {columns.map((c) => (
                  <TableCell key={c}><b>{c}</b></TableCell>
                ))}
                <TableCell><b>Delete</b></TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {previewRows.map((row) => (
                <TableRow key={row.id}>
                  {columns.map((c) => (
                    <TableCell key={c}>
                      <TextField size="small" value={row[c] || ""} onChange={(e) => updateCell(row.id, c, e.target.value)} />
                    </TableCell>
                  ))}

                  <TableCell>
                    <Button color="error" startIcon={<DeleteIcon />} onClick={() => deleteRow(row.id)}>
                      Delete
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <Button
            variant="contained"
            sx={{
              mt: 3,
              background: "#1976d2",
              "&:hover": { background: "#0d47a1" },
              borderRadius: 2,
            }}
            onClick={saveToMaster}
          >
            Save to Master List
          </Button>
        </Card>
      )}

      {/* MASTER LIST */}
      {tab === "master" && (
        <Card sx={{ mt: 3, p: 3, borderRadius: 3, boxShadow: 4 }}>
          <Typography variant="h6" sx={{ mb: 1, color: "#0288d1" }}>
            Master List
          </Typography>
          <Divider sx={{ mb: 2 }} />

          {/* LAST UPDATED DATE (ADDED HERE) */}
          {lastUpdated && (
            <Typography sx={{ mb: 2, fontSize: "15px", color: "green" }}>
              <b>Last Updated:</b> {lastUpdated}
            </Typography>
          )}

          <Table>
            <TableHead sx={{ background: "#e1f5fe" }}>
              <TableRow>
                <TableCell><b>Select</b></TableCell>
                {columns.map((h) => (
                  <TableCell key={h}><b>{h}</b></TableCell>
                ))}
                <TableCell><b>Status</b></TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {masterList.map((row) => (
                <TableRow key={row.id}>
                  <TableCell>
                    <Checkbox
                      checked={row.status === "Assigned"}
                      onChange={() => toggleAssign(row.id)}
                    />
                  </TableCell>

                  {columns.map((c) => (
                    <TableCell key={c}>{row[c]}</TableCell>
                  ))}

                  <TableCell>{row.status}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <Button
            variant="contained"
            sx={{
              mt: 2,
              background: "#e65100",
              "&:hover": { background: "#bf360c" },
              borderRadius: 2,
            }}
            onClick={pushToInactive}
          >
            Move Assigned → Inactive
          </Button>
        </Card>
      )}

      {/* INACTIVE */}
      {tab === "inactive" && (
        <Card sx={{ mt: 3, p: 3, borderRadius: 3, boxShadow: 4 }}>
          <Typography variant="h6" sx={{ mb: 1, color: "#c62828" }}>
            Inactive List
          </Typography>
          <Divider sx={{ mb: 2 }} />

          <Table>
            <TableHead sx={{ background: "#ffebee" }}>
              <TableRow>
                {columns.map((h) => (
                  <TableCell key={h}><b>{h}</b></TableCell>
                ))}
                <TableCell><b>Status</b></TableCell>
                <TableCell><b>Reassign</b></TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {inactiveList.map((row) => (
                <TableRow key={row.id}>
                  {columns.map((c) => (
                    <TableCell key={c}>{row[c]}</TableCell>
                  ))}
                  <TableCell>{row.status}</TableCell>

                  <TableCell>
                    <Button
                      startIcon={<ReplayIcon />}
                      variant="contained"
                      sx={{
                        background: "#2e7d32",
                        "&:hover": { background: "#1b5e20" },
                        borderRadius: 2,
                      }}
                      onClick={() => reassign(row.id)}
                    >
                      Reassign
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* ALERT */}
      <Snackbar
        open={alert.open}
        autoHideDuration={3000}
        onClose={() => setAlert({ ...alert, open: false })}
      >
        <Alert severity={alert.type}>{alert.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
