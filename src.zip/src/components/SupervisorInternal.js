import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  TextField,
  Typography,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
  Grid,
  Card,
  IconButton,
  CardContent,
  AppBar,
  Toolbar,
  Alert,
  TableContainer,
  CardActionArea,
  Snackbar,
} from "@mui/material";

import LogoutIcon from "@mui/icons-material/Logout";
import { PieChart, Pie, Cell, Legend, Tooltip } from "recharts";
import {
  AssignmentTurnedIn,
  EditNote,
  GroupAdd,
  Dashboard,
} from "@mui/icons-material";

/**
 * SupervisorInternal
 *
 * Notes:
 * - Uses dummy data when DB returns nothing (simulated in useEffect).
 * - Option A: Single PCB assignment flow.
 * - Save sends POST to /api/saveAssignments (placeholder) with savedAt timestamp.
 *   If network/save fails, falls back to localStorage.
 */

const SupervisorInternal = ({ onLogout, inActionPCBs = [], handleAssignWork }) => {
  const [activeTab, setActiveTab] = useState(null);
  const [operators, setOperators] = useState([]);
  const [selectedPCB, setSelectedPCB] = useState(null);

  const [newOperator, setNewOperator] = useState({
    name: "",
    email: "",
    skill: "",
  });

  // --- New states for Assign Task functionality ---
  const [pcbList, setPcbList] = useState([]); // from DB or dummy
  const [operatorList, setOperatorList] = useState([]); // from DB or dummy
  const [taskList, setTaskList] = useState([]); // from JSON (dummy)

  const [showAssignForm, setShowAssignForm] = useState(false);
  const [selectedPCBNo, setSelectedPCBNo] = useState("");
  const [selectedTask, setSelectedTask] = useState("");
  const [selectedOperator, setSelectedOperator] = useState("");

  const [assignedTable, setAssignedTable] = useState([]); // rows added via Update
  const [assignSavedForPCB, setAssignSavedForPCB] = useState(false); // disables Save after success

  // Snackbars
  const [snack, setSnack] = useState({ open: false, severity: "success", message: "" });

  const COLORS = ["#8884d8", "#82ca9d"];
  const dataSourceForCounts = inActionPCBs && inActionPCBs.length ? inActionPCBs : pcbList;
  const taskData = [
    { name: "Pending", value: dataSourceForCounts.filter((p) => !p.isWorkAssigned).length },
    { name: "Assigned", value: dataSourceForCounts.filter((p) => p.isWorkAssigned).length },
  ];

  useEffect(() => {
    // Simulate fetching from DB. Replace with real API calls later.
    const dummyPCBs = [
      { id: 1, serial: "PCB-1001", isWorkAssigned: false, linkedOperations: [{ id: 1 }, { id: 2 }] },
      { id: 2, serial: "PCB-1002", isWorkAssigned: false, linkedOperations: [{ id: 1 }] },
      { id: 3, serial: "PCB-1003", isWorkAssigned: true, linkedOperations: [{ id: 1 }, { id: 2 }, { id: 3 }] },
    ];

    const dummyOperators = [
      { id: 1, name: "Operator A" },
      { id: 2, name: "Operator B" },
      { id: 3, name: "Operator C" },
    ];

    const dummyTasks = [
      { id: 1, taskName: "Soldering" },
      { id: 2, taskName: "Inspection" },
      { id: 3, taskName: "Wiring" },
      { id: 4, taskName: "Testing" },
    ];

    // Simulated DB responses (empty arrays represent no data from DB)
    const dbPCBs = []; // pretend there's no data from DB for now
    const dbOperators = []; // pretend empty
    const dbTasks = []; // pretend empty

    setPcbList(dbPCBs.length ? dbPCBs : dummyPCBs);
    setOperatorList(dbOperators.length ? dbOperators : dummyOperators);
    setTaskList(dbTasks.length ? dbTasks : dummyTasks);
  }, []);

  const handleAddOperator = () => {
    if (!newOperator.name || !newOperator.email) return alert("Fill all details");

    setOperators([...operators, newOperator]);
    setNewOperator({ name: "", email: "", skill: "" });
  };

  /* ----------------------------- SAVE ASSIGNMENTS (Single PCB) ----------------------------- */
  const canSave = () => {
    // Option A: single PCB mode
    if (!selectedPCBNo) return false;
    if (assignSavedForPCB) return false; // already saved
    if (assignedTable.length === 0) return false;
    // all assigned rows must belong to selectedPCBNo
    return assignedTable.every((r) => r.pcbNo === selectedPCBNo);
  };

  const saveAssignments = async () => {
    if (!canSave()) return;

    const payload = {
      pcb: selectedPCBNo,
      assignments: assignedTable.filter((r) => r.pcbNo === selectedPCBNo),
      savedAt: new Date().toISOString(),
    };

    try {
      // Replace the URL below with your real API endpoint
      const res = await fetch("/api/saveAssignments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error(`Save failed: ${res.status}`);

      // success
      setSnack({ open: true, severity: "success", message: "Assignments saved to database." });
      setAssignSavedForPCB(true);

      // mark PCB as assigned in local pcbList (and inActionPCBs if used)
      setPcbList((prev) => prev.map((p) => (p.serial === selectedPCBNo ? { ...p, isWorkAssigned: true } : p)));
    } catch (err) {
      // fallback: save to localStorage
      try {
        const fallbackKey = `assignments_fallback_${selectedPCBNo}_${new Date().toISOString()}`;
        localStorage.setItem(fallbackKey, JSON.stringify(payload));
        setSnack({ open: true, severity: "warning", message: "Save to DB failed — assignments saved locally." });
        setAssignSavedForPCB(true);
        // mark local pcbList assigned
        setPcbList((prev) => prev.map((p) => (p.serial === selectedPCBNo ? { ...p, isWorkAssigned: true } : p)));
      } catch (lsErr) {
        setSnack({ open: true, severity: "error", message: "Save failed and local fallback also failed." });
      }
    }
  };

  /* ----------------------------- ASSIGN PCB UI ----------------------------- */
  const renderAssignPCB = () => {
    // Use inActionPCBs prop if provided, else pcbList
    const sourcePCBs = inActionPCBs && inActionPCBs.length ? inActionPCBs : pcbList;

    if (!sourcePCBs || sourcePCBs.length === 0) {
      return (
        <Typography sx={{ p: 3, textAlign: "center" }}>
          No PCBs available for assignment.
        </Typography>
      );
    }

    const keyName = sourcePCBs[0]?._pcb_key_id ? "_pcb_key_id" : "serial";

    const baseColumns = Object.keys(sourcePCBs[0]).filter(
      (k) => !["id", "linkedOperations", "isWorkAssigned", "_pcb_key_id"].includes(k)
    );

    return (
      <>
        {selectedPCB && (
          <Alert
            severity="info"
            onClose={() => setSelectedPCB(null)}
            sx={{ mb: 2 }}
          >
            <strong>PCB:</strong> {selectedPCB[keyName]} — Mandatory Ops:{" "}
            {selectedPCB.linkedOperations?.length ?? 0}
          </Alert>
        )}

        {/* ---------- Assign Form (appears after clicking 'Assign Work') ---------- */}
        {showAssignForm && (
          <Card sx={{ p: 2, mb: 3, borderRadius: 2, background: "#EEF2FF" }}>
            <Typography variant="h6" sx={{ mb: 2 }}>
              Assign Work
            </Typography>

            <Grid container spacing={2}>
              {/* 1. PCB dropdown */}
              <Grid item xs={12} md={4}>
                <TextField
                  select
                  fullWidth
                  label="Select PCB"
                  value={selectedPCBNo}
                  onChange={(e) => {
                    setSelectedPCBNo(e.target.value);
                    // reset assigned table when PCB changed (single PCB flow)
                    setAssignedTable([]);
                    setAssignSavedForPCB(false);
                  }}
                  SelectProps={{ native: true }}
                >
                  <option value=""></option>
                  {pcbList.map((p) => (
                    <option key={p.id} value={p.serial ?? p._pcb_key_id ?? p.serial}>
                      {p.serial ?? p._pcb_key_id ?? p.serial}
                    </option>
                  ))}
                </TextField>
              </Grid>

              {/* 2. Task dropdown (from JSON) */}
              <Grid item xs={12} md={4}>
                <TextField
                  select
                  fullWidth
                  label="Select Task"
                  value={selectedTask}
                  onChange={(e) => setSelectedTask(e.target.value)}
                  SelectProps={{ native: true }}
                >
                  <option value=""></option>
                  {taskList.map((t) => (
                    <option key={t.id} value={t.taskName}>
                      {t.taskName}
                    </option>
                  ))}
                </TextField>
              </Grid>

              {/* 3. Operator dropdown */}
              <Grid item xs={12} md={4}>
                <TextField
                  select
                  fullWidth
                  label="Select Operator"
                  value={selectedOperator}
                  onChange={(e) => setSelectedOperator(e.target.value)}
                  SelectProps={{ native: true }}
                >
                  <option value=""></option>
                  {operatorList.map((op) => (
                    <option key={op.id} value={op.name}>
                      {op.name}
                    </option>
                  ))}
                </TextField>
              </Grid>

              {/* Update button */}
              <Grid item xs={12}>
                <Button
                  variant="contained"
                  onClick={() => {
                    if (!selectedPCBNo || !selectedTask || !selectedOperator)
                      return alert("Please choose PCB, Task and Operator");

                    // compute slno and stageId (single PCB)
                    const slno = assignedTable.length + 1;
                    const stageId = assignedTable.length === 0 ? 1 : slno;

                    const newEntry = {
                      slno,
                      taskName: selectedTask,
                      stageId,
                      status: "Not Yet Assigned",
                      pcbNo: selectedPCBNo,
                      operator: selectedOperator,
                    };

                    setAssignedTable((prev) => [...prev, newEntry]);

                    // Reset task & operator for next assignment but keep PCB selected
                    setSelectedTask("");
                    setSelectedOperator("");
                    // Keep form open for further assignments
                  }}
                >
                  Update
                </Button>
              </Grid>
            </Grid>
          </Card>
        )}

        {/* ---------- PCB Table ---------- */}
        <TableContainer
          component={Paper}
          sx={{ maxHeight: 420, minHeight: 300, borderRadius: 3, boxShadow: 3 }}
        >
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                {baseColumns.map((col) => (
                  <TableCell key={col}>{col}</TableCell>
                ))}
                <TableCell>Status</TableCell>
                <TableCell>Assign</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {sourcePCBs.map((pcb, i) => {
                const serialNumber = pcb._pcb_key_id ?? pcb.serial ?? pcb[keyName] ?? `pcb-${i}`;
                return (
                  <TableRow key={i}>
                    {baseColumns.map((col) => (
                      <TableCell key={col}>
                        {col === keyName ? (
                          <Button variant="text" onClick={() => setSelectedPCB(pcb)}>
                            {serialNumber}
                          </Button>
                        ) : (
                          pcb[col]
                        )}
                      </TableCell>
                    ))}

                    <TableCell
                      sx={{
                        fontWeight: "bold",
                        color: pcb.isWorkAssigned ? "green" : "red",
                      }}
                    >
                      {pcb.isWorkAssigned ? "ASSIGNED" : "PENDING"}
                    </TableCell>

                    <TableCell>
                      <Button
                        variant="contained"
                        disabled={pcb.isWorkAssigned}
                        onClick={() => {
                          // Open assign form and pre-select PCB (single PCB flow)
                          setShowAssignForm(true);
                          const sn = serialNumber;
                          setSelectedPCBNo(sn);
                          // Reset assigned table for new PCB
                          setAssignedTable([]);
                          setAssignSavedForPCB(false);
                        }}
                      >
                        {pcb.isWorkAssigned ? "Assigned" : "Assign Work"}
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>

        {/* ---------- Assigned Work Table (sl.no, task name, stage id, status) ---------- */}
        {assignedTable.length > 0 && (
          <Card sx={{ p: 2, mt: 3 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>
              Assigned Work Table (PCB: {selectedPCBNo || "—"})
            </Typography>

            <Table>
              <TableHead>
                <TableRow>
                  <TableCell><b>Sl.No</b></TableCell>
                  <TableCell><b>Task Name</b></TableCell>
                  <TableCell><b>Stage ID</b></TableCell>
                  <TableCell><b>Status</b></TableCell>
                </TableRow>
              </TableHead>

              <TableBody>
                {assignedTable.map((row) => (
                  <TableRow key={row.slno}>
                    <TableCell>{row.slno}</TableCell>
                    <TableCell>{row.taskName}</TableCell>
                    <TableCell>{row.stageId}</TableCell>
                    <TableCell>{row.status}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {/* Save Button - only enabled when assignments exist for the selected PCB */}
            <Box sx={{ mt: 2, display: "flex", gap: 2, alignItems: "center" }}>
              <Button
                variant="contained"
                color="primary"
                disabled={!canSave()}
                onClick={saveAssignments}
              >
                Save
              </Button>

              {assignSavedForPCB && (
                <Typography color="success.main">Saved ✔</Typography>
              )}

              <Typography sx={{ ml: 2, color: "text.secondary", fontSize: 13 }}>
                (Save stores assignments and timestamp in DB — fallback to localStorage if DB unavailable)
              </Typography>
            </Box>
          </Card>
        )}
      </>
    );
  };

  /* ----------------------------- TAB CONTENT ----------------------------- */
  const renderContent = () => {
    switch (activeTab?.key) {
      case "dashboard":
        return (
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Card sx={{ p: 2, borderRadius: 3, boxShadow: 4 }}>
                <Typography variant="h6">PCB Status</Typography>

                <PieChart width={320} height={260}>
                  <Pie
                    data={taskData}
                    cx={150}
                    cy={120}
                    outerRadius={80}
                    label
                    dataKey="value"
                  >
                    {taskData.map((entry, index) => (
                      <Cell key={index} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </Card>
            </Grid>

            <Grid item xs={12} md={6}>
              <Card sx={{ p: 2, borderRadius: 3, boxShadow: 4 }}>
                <Typography variant="h6">Summary</Typography>

                <Typography>Total Operators: {operators.length}</Typography>
                <Typography>Total PCBs: {(inActionPCBs.length ? inActionPCBs.length : pcbList.length)}</Typography>
                <Typography>
                  Assigned: {(inActionPCBs.length ? inActionPCBs.filter((p) => p.isWorkAssigned).length : pcbList.filter(p => p.isWorkAssigned).length)}
                </Typography>
                <Typography>
                  Pending: {(inActionPCBs.length ? inActionPCBs.filter((p) => !p.isWorkAssigned).length : pcbList.filter(p => !p.isWorkAssigned).length)}
                </Typography>
              </Card>
            </Grid>
          </Grid>
        );

      case "createOperator":
        return (
          <Box sx={{ maxWidth: 600 }}>
            <TextField
              label="Name"
              fullWidth
              sx={{ mb: 2 }}
              value={newOperator.name}
              onChange={(e) =>
                setNewOperator({ ...newOperator, name: e.target.value })
              }
            />

            <TextField
              label="Email"
              fullWidth
              sx={{ mb: 2 }}
              value={newOperator.email}
              onChange={(e) =>
                setNewOperator({ ...newOperator, email: e.target.value })
              }
            />

            <TextField
              label="Skill"
              fullWidth
              sx={{ mb: 2 }}
              value={newOperator.skill}
              onChange={(e) =>
                setNewOperator({ ...newOperator, skill: e.target.value })
              }
            />

            <Button variant="contained" onClick={handleAddOperator}>
              Add Operator
            </Button>

            <Typography variant="h6" sx={{ mt: 3 }}>
              Operator List
            </Typography>

            <TableContainer component={Paper} sx={{ mt: 2, borderRadius: 2 }}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Name</TableCell>
                    <TableCell>Email</TableCell>
                    <TableCell>Skill</TableCell>
                  </TableRow>
                </TableHead>

                <TableBody>
                  {operators.map((op, i) => (
                    <TableRow key={i}>
                      <TableCell>{op.name}</TableCell>
                      <TableCell>{op.email}</TableCell>
                      <TableCell>{op.skill}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        );

      case "assignTask":
        return renderAssignPCB();

      case "corrections":
        return (
          <Typography sx={{ mt: 2 }}>
            Correction requests will come from backend.
          </Typography>
        );

      default:
        return null;
    }
  };

  /* ----------------------------- MENU CARDS ----------------------------- */
  const menuItems = [
    {
      key: "dashboard",
      text: "Dashboard",
      icon: <Dashboard sx={{ fontSize: 55, color: "white" }} />,
    },
    {
      key: "createOperator",
      text: "Manage User",
      icon: <GroupAdd sx={{ fontSize: 55, color: "white" }} />,
    },
    {
      key: "assignTask",
      text: "Assign Task",
      icon: <AssignmentTurnedIn sx={{ fontSize: 55, color: "white" }} />,
    },
    {
      key: "corrections",
      text: "Corrections",
      icon: <EditNote sx={{ fontSize: 55, color: "white" }} />,
    },
  ];

  return (
    <Box sx={{ minHeight: "100vh", bgcolor: "#F1F5F9" }}>
      <AppBar sx={{ bgcolor: "#3949AB" }}>
        <Toolbar>
          <Typography sx={{ flexGrow: 1 }} variant="h5">
            Supervisor Internal Dashboard
          </Typography>

          <IconButton color="inherit" onClick={onLogout}>
            <LogoutIcon />
          </IconButton>
        </Toolbar>
      </AppBar>

      {/* MENU CARDS */}
      {!activeTab && (
        <Grid
          container
          spacing={4}
          sx={{
            p: 5,
            justifyContent: "center",
            animation: "fadeIn .4s",
          }}
        >
          {menuItems.map((item) => (
            <Grid item xs={12} sm={6} md={3} key={item.key}>
              <Card
                onClick={() => setActiveTab(item)}
                sx={{
                  height: 200,
                  borderRadius: 3,
                  background: "#1E293B",
                  color: "white",
                  boxShadow: "0 6px 20px rgba(0,0,0,0.18)",
                  transition: "0.35s",
                  "&:hover": {
                    transform: "translateY(-10px)",
                    boxShadow: "0 12px 32px rgba(57,73,171,0.4)",
                  },
                }}
              >
                <CardActionArea sx={{ height: "100%" }}>
                  <CardContent
                    sx={{
                      height: "100%",
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    {item.icon}
                    <Typography sx={{ mt: 2 }} variant="h6">
                      {item.text}
                    </Typography>
                  </CardContent>
                </CardActionArea>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}

      {/* CONTENT */}
      {activeTab && (
        <Box
          sx={{
            p: 4,
            animation: "zoom .4s",
          }}
        >
          <Card sx={{ p: 3, borderRadius: 3, boxShadow: 4 }}>
            <Typography variant="h4" sx={{ mb: 2, color: "#3949AB", fontWeight: 700 }}>
              {activeTab.text}
            </Typography>

            <Typography
              sx={{
                mb: 3,
                cursor: "pointer",
                color: "#3949AB",
                fontWeight: 600,
                "&:hover": { textDecoration: "underline" },
              }}
              onClick={() => setActiveTab(null)}
            >
              ← Back to Menu
            </Typography>

            {renderContent()}
          </Card>
        </Box>
      )}

      {/* Snack */}
      <Snackbar
        open={snack.open}
        autoHideDuration={4000}
        onClose={() => setSnack((s) => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert severity={snack.severity} onClose={() => setSnack((s) => ({ ...s, open: false }))}>
          {snack.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default SupervisorInternal;
