import React, { useState } from "react";
import {
  Box,
  TextField,
  Button,
  Typography,
  MenuItem,
  Card,
  CardContent,
} from "@mui/material";
import FactoryIcon from "@mui/icons-material/Factory";
import LoginIcon from "@mui/icons-material/Login";

const LoginPage = ({ onLogin }) => {
  const [company, setCompany] = useState("");
  const [sbu, setSbu] = useState("");
  const [division, setDivision] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    if (!onLogin) return alert("Login function not connected yet!");
    onLogin(username, password);
  };

  return (
    <Box
      sx={{
        height: "100vh",
        background: "linear-gradient(135deg, #3E3E3E, #1E1E1E)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        color: "#fff",
      }}
    >
      <Card
        sx={{
          width: 380,
          borderRadius: 3,
          boxShadow: "0 8px 25px rgba(0,0,0,0.5)",
          background:
            "linear-gradient(145deg, #2E2E2E 0%, #212121 100%)",
          border: "2px solid #F9A825", // yellow border
        }}
      >
        <CardContent sx={{ textAlign: "center", p: 4 }}>
          <FactoryIcon sx={{ fontSize: 60, color: "#FBC02D", mb: 1 }} />
          <Typography
            variant="h5"
            sx={{
              mb: 3,
              fontWeight: "bold",
              color: "#FBC02D",
              textShadow: "1px 1px 2px rgba(0,0,0,0.8)",
            }}
          >
            Assembly Line Login
          </Typography>

          {/* Fields stacked vertically */}
          <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
            <TextField
              select
              label="Company Name"
              value={company}
              onChange={(e) => setCompany(e.target.value)}
              fullWidth
              variant="filled"
              sx={{
                backgroundColor: "#fff",
                borderRadius: 1,
              }}
            >
              <MenuItem value="IndusWorks">IndusWorks</MenuItem>
              <MenuItem value="TechFabric">TechFabric</MenuItem>
              <MenuItem value="SteelPro">SteelPro</MenuItem>
            </TextField>

            <TextField
              select
              label="SBU"
              value={sbu}
              onChange={(e) => setSbu(e.target.value)}
              fullWidth
              variant="filled"
              sx={{ backgroundColor: "#fff", borderRadius: 1 }}
            >
              <MenuItem value="Manufacturing">Manufacturing</MenuItem>
              <MenuItem value="Testing">Testing</MenuItem>
              <MenuItem value="Assembly">Assembly</MenuItem>
            </TextField>

            <TextField
              select
              label="Sub Division"
              value={division}
              onChange={(e) => setDivision(e.target.value)}
              fullWidth
              variant="filled"
              sx={{ backgroundColor: "#fff", borderRadius: 1 }}
            >
              <MenuItem value="Line 1">Line 1</MenuItem>
              <MenuItem value="Line 2">Line 2</MenuItem>
              <MenuItem value="Line 3">Line 3</MenuItem>
            </TextField>

            <TextField
              label="Username"
              variant="filled"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              fullWidth
              sx={{ backgroundColor: "#fff", borderRadius: 1 }}
            />

            <TextField
              label="Password"
              type="password"
              variant="filled"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              fullWidth
              sx={{ backgroundColor: "#fff", borderRadius: 1 }}
            />

            <Button
              variant="contained"
              endIcon={<LoginIcon />}
              onClick={handleLogin}
              sx={{
                mt: 2,
                py: 1.3,
                borderRadius: 2,
                fontWeight: "bold",
                background:
                  "linear-gradient(90deg, #FBC02D 0%, #F57F17 100%)",
                color: "#000",
                "&:hover": {
                  background:
                    "linear-gradient(90deg, #F57F17 0%, #FBC02D 100%)",
                },
                boxShadow: "0 4px 10px rgba(255,193,7,0.4)",
              }}
            >
              LOGIN
            </Button>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
};

export default LoginPage;
