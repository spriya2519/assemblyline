import React, { useState } from "react";
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  AppBar,
  Toolbar,
  IconButton,
  CardActionArea,
} from "@mui/material";
import LogoutIcon from "@mui/icons-material/Logout";
import { Dashboard } from "@mui/icons-material";

import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";

const SupervisorExternal = ({ onLogout }) => {
  // Dummy data
  const tasks = [
    { name: "Task 1", status: "Completed" },
    { name: "Task 2", status: "Pending" },
    { name: "Task 3", status: "Pending" },
    { name: "Task 4", status: "Completed" },
    { name: "Task 5", status: "Completed" },
  ];

  const completedCount = tasks.filter((t) => t.status === "Completed").length;
  const pendingCount = tasks.filter((t) => t.status === "Pending").length;

  const pieData = [
    { name: "Completed", value: completedCount },
    { name: "Pending", value: pendingCount },
  ];

  const COLORS = ["#4CAF50", "#F44336"];

  const barData = [
    { name: "Completed", value: completedCount },
    { name: "Pending", value: pendingCount },
  ];

  // ------- CARD MENU (like AdminDashboard) -------
  const menu = [
    { text: "Dashboard", icon: <Dashboard sx={{ fontSize: 55, color: "white" }} /> },
  ];

  const [selected, setSelected] = useState(null);

  return (
    <Box sx={{ minHeight: "100vh", bgcolor: "#ECEFF1" }}>
      {/* Top App Bar */}
      <AppBar
        position="static"
        sx={{
          backgroundColor: "#37474F",
          mb: 2,
          boxShadow: 0,
        }}
      >
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            {selected ? selected.text : "External Supervisor Dashboard"}
          </Typography>

          <IconButton color="inherit" onClick={onLogout}>
            <LogoutIcon />
          </IconButton>
        </Toolbar>
      </AppBar>

      {/* ===== CARD MENU (instead of sidebar) ===== */}
      {!selected && (
        <Grid
          container
          spacing={4}
          sx={{
            p: 4,
            display: "flex",
            justifyContent: "center",
            animation: "fadeIn 0.4s ease",
            "@keyframes fadeIn": {
              from: { opacity: 0, transform: "translateY(10px)" },
              to: { opacity: 1, transform: "translateY(0)" },
            },
          }}
        >
          {menu.map((item) => (
            <Grid item xs={12} sm={6} md={3} key={item.text}>
              <Card
                sx={{
                  height: 200,
                  borderRadius: 3,
                  background: "#1E293B",
                  color: "white",
                  boxShadow: "0 6px 20px rgba(0,0,0,0.18)",
                  transition: "0.35s",
                  "&:hover": {
                    transform: "translateY(-10px)",
                    boxShadow: "0 12px 30px rgba(0,0,0,0.4)",
                  },
                }}
              >
                <CardActionArea sx={{ height: "100%" }} onClick={() => setSelected(item)}>
                  <CardContent
                    sx={{
                      height: "100%",
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    {item.icon}
                    <Typography variant="h6" sx={{ mt: 2, fontWeight: 600 }}>
                      {item.text}
                    </Typography>
                  </CardContent>
                </CardActionArea>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}

      {/* ===== SELECTED PAGE ===== */}
      {selected && (
        <Box
          sx={{
            p: 4,
            animation: "zoomIn 0.4s",
            "@keyframes zoomIn": {
              from: { opacity: 0, transform: "scale(0.96)" },
              to: { opacity: 1, transform: "scale(1)" },
            },
          }}
        >
          <Card sx={{ p: 3, borderRadius: 3, boxShadow: 4 }}>
            <Typography variant="h4" sx={{ mb: 2, fontWeight: 700, color: "#37474F" }}>
              {selected.text}
            </Typography>

            {/* Back link */}
            <Typography
              sx={{
                mb: 3,
                cursor: "pointer",
                color: "#3949AB",
                fontSize: 18,
                fontWeight: 600,
                "&:hover": { textDecoration: "underline" },
              }}
              onClick={() => setSelected(null)}
            >
              ← Back to Menu
            </Typography>

            {/* MAIN DASHBOARD CONTENT */}
            <Grid container spacing={3}>
              {/* Pie Chart */}
              <Grid item xs={12} md={6}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Task Status Overview
                    </Typography>
                    <PieChart width={300} height={300}>
                      <Pie
                        data={pieData}
                        dataKey="value"
                        cx="50%"
                        cy="50%"
                        outerRadius={90}
                        label
                      >
                        {pieData.map((entry, index) => (
                          <Cell
                            key={index}
                            fill={COLORS[index % COLORS.length]}
                          />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </CardContent>
                </Card>
              </Grid>

              {/* Bar Chart */}
              <Grid item xs={12} md={6}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Task Distribution
                    </Typography>
                    <BarChart
                      width={350}
                      height={300}
                      data={barData}
                      margin={{ top: 20, right: 20, left: 0, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="value" fill="#2196F3" />
                    </BarChart>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            {/* Summary Cards */}
            <Grid container spacing={3} sx={{ mt: 2 }}>
              <Grid item xs={12} md={6}>
                <Card sx={{ bgcolor: "#C8E6C9" }}>
                  <CardContent>
                    <Typography variant="h6">Completed Tasks</Typography>
                    <Typography variant="h4" color="success.main">
                      {completedCount}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={6}>
                <Card sx={{ bgcolor: "#FFCDD2" }}>
                  <CardContent>
                    <Typography variant="h6">Pending Tasks</Typography>
                    <Typography variant="h4" color="error.main">
                      {pendingCount}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Card>
        </Box>
      )}
    </Box>
  );
};

export default SupervisorExternal;
